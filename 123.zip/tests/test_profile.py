from __future__ import annotations

import math
import random
from datetime import datetime, timedelta, timezone
from typing import Iterable, List, Mapping

import pytest
from fastapi.testclient import TestClient

from src.api.app import app
import src.services.inspection as inspection
from src.meta import Meta
from src.services import presets
from src.services.profile import (
    build_compact_vwap_profiles,
    build_profile_package,
    build_volume_profile,
    compute_session_profiles,
    flatten_profile,
    split_by_sessions,
)


@pytest.fixture()
def client() -> TestClient:
    return TestClient(app)


@pytest.fixture(autouse=True)
def preset_storage(tmp_path, monkeypatch):
    storage_path = tmp_path / "presets.json"
    monkeypatch.setattr(presets, "_PRESET_STORAGE_PATH", storage_path)
    presets._PRESET_CACHE.clear()
    presets._STORAGE_LOADED = False
    yield
    presets._PRESET_CACHE.clear()
    presets._STORAGE_LOADED = False


@pytest.fixture(autouse=True)
def snapshot_storage(tmp_path, monkeypatch):
    storage_dir = tmp_path / "snapshots"
    monkeypatch.setattr(inspection, "SNAPSHOT_STORAGE_DIR", storage_dir)
    inspection._SNAPSHOT_STORE.clear()
    inspection._ensure_storage_dir()
    inspection._load_existing_snapshots()
    yield storage_dir
    inspection._SNAPSHOT_STORE.clear()


def make_unimodal(
    *,
    center: float = 100.0,
    spread: float = 0.5,
    n: int = 200,
    seed: int = 42,
    base: datetime | None = None,
) -> List[Mapping[str, float]]:
    rng = random.Random(seed)
    start = base or datetime(2024, 1, 1, tzinfo=timezone.utc)
    candles = []
    for index in range(n):
        moment = start + timedelta(minutes=index)
        timestamp = int(moment.timestamp() * 1000)
        price = rng.gauss(center, spread)
        high = price + abs(rng.gauss(spread * 0.9, spread * 0.4))
        low = price - abs(rng.gauss(spread * 0.9, spread * 0.4))
        open_price = price + rng.uniform(-spread * 0.4, spread * 0.4)
        close_price = price
        volume = abs(rng.gauss(12.0, 2.0)) + 1.0
        candles.append(
            {
                "t": timestamp,
                "o": round(open_price, 4),
                "h": round(high, 4),
                "l": round(low, 4),
                "c": round(close_price, 4),
                "v": round(volume, 4),
            }
        )
    return candles


def make_bimodal(
    *,
    left: float = 100.0,
    right: float = 102.0,
    n: int = 240,
    seed: int = 7,
    base: datetime | None = None,
) -> List[Mapping[str, float]]:
    rng = random.Random(seed)
    start = base or datetime(2024, 1, 2, tzinfo=timezone.utc)
    candles = []
    for index in range(n):
        moment = start + timedelta(minutes=index)
        timestamp = int(moment.timestamp() * 1000)
        cluster_center = right if index % 2 else left
        spread = 0.35 if index % 2 else 0.55
        price = rng.gauss(cluster_center, spread)
        high = price + abs(rng.gauss(spread * 1.2, spread * 0.5))
        low = price - abs(rng.gauss(spread * 1.2, spread * 0.5))
        open_price = price + rng.uniform(-spread * 0.4, spread * 0.4)
        close_price = price
        volume = (18.0 if index % 2 else 10.0) + abs(rng.gauss(0.0, 1.5))
        candles.append(
            {
                "t": timestamp,
                "o": round(open_price, 4),
                "h": round(high, 4),
                "l": round(low, 4),
                "c": round(close_price, 4),
                "v": round(volume, 4),
            }
        )
    return candles


def test_volume_profile_unimodal_focus() -> None:
    candles = make_unimodal(center=250.0, spread=0.8, n=360)
    profile = build_volume_profile(candles, tick_size=0.1, adaptive_bins=False, value_area_pct=0.7)

    assert profile.prices, "Profile should contain bins"
    assert math.isfinite(profile.poc)
    assert abs(profile.poc - 250.0) <= 0.6
    flattened = flatten_profile(profile)
    total_volume = sum(entry["volume"] for entry in flattened)
    assert total_volume > 0
    within_value_area = [
        entry for entry in flattened if profile.val <= entry["price"] <= profile.vah
    ]
    value_volume = sum(entry["volume"] for entry in within_value_area)
    assert value_volume / total_volume >= 0.65
    assert "warn" not in profile.diagnostics


def test_volume_profile_bimodal_prefers_dominant_peak() -> None:
    candles = make_bimodal(left=200.0, right=205.0, n=300)
    profile = build_volume_profile(candles, tick_size=0.25, adaptive_bins=False, value_area_pct=0.7)

    assert math.isfinite(profile.poc)
    assert abs(profile.poc - 205.0) <= 0.75
    assert profile.vah >= profile.val
    flattened = flatten_profile(profile)
    total_volume = sum(entry["volume"] for entry in flattened)
    assert total_volume > 0
    covered = sum(entry["volume"] for entry in flattened if profile.val <= entry["price"] <= profile.vah)
    assert covered / total_volume >= 0.65


def test_volume_profile_warns_on_short_series() -> None:
    candles = make_unimodal(n=10)
    profile = build_volume_profile(candles, tick_size=0.1, adaptive_bins=False, value_area_pct=0.7)
    assert profile.diagnostics.get("warn") == "too_few_bars"
    assert profile.poc is None
    assert profile.vah is None
    assert profile.val is None


def test_split_by_sessions_groups_candles() -> None:
    base = datetime(2024, 5, 1, tzinfo=timezone.utc)
    candles = make_unimodal(n=600, base=base)
    sessions = list(Meta.iter_vwap_sessions())
    result = split_by_sessions(candles, sessions)
    buckets = result.buckets
    assert buckets, "Expected session buckets"
    assert result.sessions_empty is False
    asia_key = (base.date(), sessions[0][0])
    london_key = (base.date(), sessions[1][0])
    assert asia_key in buckets
    assert london_key in buckets
    assert len(buckets[asia_key]) > 0
    assert len(buckets[london_key]) > 0


def _snapshot_payload(candles: Iterable[Mapping[str, float]]) -> Mapping[str, object]:
    return {
        "symbol": "BTCUSDT",
        "tf": "1m",
        "frames": {
            "1m": {
                "tf": "1m",
                "candles": list(candles),
            }
        },
    }


def test_compute_session_profiles_respects_last_n() -> None:
    base = datetime(2024, 5, 1, tzinfo=timezone.utc)
    candles = make_unimodal(n=60 * 24 * 4, base=base)
    sessions = list(Meta.iter_vwap_sessions())
    summaries = compute_session_profiles(
        candles,
        sessions=sessions,
        last_n=2,
        tick_size=0.1,
        adaptive_bins=False,
        value_area_pct=0.7,
    )
    assert summaries, "Expected at least one TPO summary"

    daily_entries = [entry for entry in summaries if entry.get("session") == "daily"]
    assert daily_entries, "Expected daily TPO entries"
    assert len(daily_entries) <= 2

    allowed_dates = {entry["date"] for entry in daily_entries}
    assert allowed_dates
    assert allowed_dates == {entry["date"] for entry in summaries}
    expected_dates = {
        (base.date() + timedelta(days=offset)).isoformat() for offset in range(2, 4)
    }
    assert allowed_dates == expected_dates

    ordered_dates = [entry["date"] for entry in summaries]
    assert ordered_dates == sorted(ordered_dates)

    for day_entry in daily_entries:
        nested = day_entry.get("sessions", [])
        assert isinstance(nested, list)
        for nested_entry in nested:
            assert nested_entry.get("date") == day_entry["date"]
    if any(day_entry.get("sessions") for day_entry in daily_entries):
        assert summaries[-1]["session"] != "daily"


def test_compute_session_profiles_marks_sparse_days() -> None:
    base = datetime(2024, 5, 10, tzinfo=timezone.utc)
    candles = make_unimodal(n=45, base=base)
    sessions = list(Meta.iter_vwap_sessions())
    summaries = compute_session_profiles(
        candles,
        sessions=sessions,
        last_n=1,
        tick_size=0.1,
        adaptive_bins=False,
        value_area_pct=0.7,
    )
    assert summaries, "Expected TPO summaries"
    daily_entry = next(entry for entry in summaries if entry.get("session") == "daily")
    diagnostics = daily_entry.get("DIAGNOSTICS")
    assert diagnostics and diagnostics.get("warn") == "too_few_bars"
    assert "POC" not in daily_entry
    assert "VAH" not in daily_entry
    assert "VAL" not in daily_entry


def test_profile_endpoint_returns_payload(client: TestClient) -> None:
    candles = make_unimodal(n=720, base=datetime(2024, 6, 1, tzinfo=timezone.utc))
    response = client.post("/inspection/snapshot", json=_snapshot_payload(candles))
    assert response.status_code == 200
    snapshot_id = response.json()["snapshot_id"]

    params = {
        "snapshot": snapshot_id,
        "last_n": 2,
        "value_area_pct": 0.7,
    }
    profile_response = client.get("/profile", params=params)
    assert profile_response.status_code == 200
    body = profile_response.json()
    assert body["symbol"] == "BTCUSDT"
    assert body["tf"] == "1m"
    assert "tpo" in body and isinstance(body["tpo"], dict)
    assert isinstance(body["tpo"].get("sessions"), list)
    assert isinstance(body["tpo"].get("zones"), list)
    assert "profile" in body and isinstance(body["profile"], list)
    assert "zones" in body and isinstance(body["zones"], dict)
    assert isinstance(body["zones"].get("zones"), dict)
    preset = body.get("preset")
    assert preset is not None
    assert preset["symbol"] == "BTCUSDT"
    assert preset["builtin"] is True
    assert body.get("preset_required") is False
    if body["tpo"]["zones"]:
        zone_types = {item["type"] for item in body["tpo"]["zones"] if isinstance(item, Mapping)}
        assert {"tpo_poc", "tpo_vah", "tpo_val"}.issubset(zone_types)
    if body["tpo"]["sessions"]:
        latest = body["tpo"]["sessions"][-1]
        assert "session" in latest
        assert "date" in latest


def test_profile_endpoint_includes_all_snapshot_days(client: TestClient) -> None:
    base = datetime(2025, 9, 21, tzinfo=timezone.utc)
    candles = make_unimodal(n=60 * 24 * 5, base=base)

    response = client.post("/inspection/snapshot", json=_snapshot_payload(candles))
    assert response.status_code == 200
    snapshot_id = response.json()["snapshot_id"]

    profile_response = client.get(
        "/profile",
        params={
            "snapshot": snapshot_id,
            "last_n": 5,
            "value_area_pct": 0.7,
        },
    )
    assert profile_response.status_code == 200
    body = profile_response.json()

    tpo_payload = body.get("tpo", {})
    assert isinstance(tpo_payload, dict)
    tpo_entries = tpo_payload.get("sessions", [])
    assert tpo_entries, "Expected TPO entries to be present"
    daily_entries = [entry for entry in tpo_entries if entry.get("session") == "daily"]
    assert len(daily_entries) == 5

    expected_dates = {
        (base.date() + timedelta(days=offset)).isoformat() for offset in range(5)
    }
    observed_dates = {entry.get("date") for entry in daily_entries}
    assert observed_dates == expected_dates

    zone_dates = {
        zone.get("date")
        for zone in body.get("tpo", {}).get("zones", [])
        if isinstance(zone, Mapping)
    }
    assert expected_dates.issubset(zone_dates)

    zone_keys = {
        (zone.get("type"), zone.get("date"), zone.get("session"))
        for zone in body.get("tpo", {}).get("zones", [])
        if isinstance(zone, Mapping)
    }
    assert len(zone_keys) == len(body.get("tpo", {}).get("zones", []))


def test_profile_package_skips_zones_for_sparse_days() -> None:
    base = datetime(2024, 9, 1, tzinfo=timezone.utc)
    candles = make_unimodal(n=40, base=base)
    sessions = list(Meta.iter_vwap_sessions())
    tpo, _, zones = build_profile_package(
        candles,
        sessions=sessions,
        last_n=1,
        tick_size=0.1,
        adaptive_bins=False,
        value_area_pct=0.7,
        atr_multiplier=0.5,
        target_bins=80,
        cache_token=None,
        tf_key="1m",
    )
    assert tpo, "Expected TPO diagnostics"
    daily_entry = next(entry for entry in tpo if entry.get("session") == "daily")
    diagnostics = daily_entry.get("DIAGNOSTICS")
    assert diagnostics and diagnostics.get("warn") == "too_few_bars"
    assert zones == []


def test_profile_endpoint_is_deterministic(client: TestClient) -> None:
    candles = make_bimodal(n=360, base=datetime(2024, 7, 1, tzinfo=timezone.utc))
    response = client.post("/inspection/snapshot", json=_snapshot_payload(candles))
    assert response.status_code == 200
    snapshot_id = response.json()["snapshot_id"]

    params = {"snapshot": snapshot_id, "adaptive_bins": True, "value_area_pct": 0.75}
    first = client.get("/profile", params=params)
    second = client.get("/profile", params=params)
    assert first.status_code == second.status_code == 200
    assert first.json() == second.json()


def test_profile_endpoint_marks_missing_preset(client: TestClient) -> None:
    candles = make_unimodal(
        n=360,
        base=datetime(2024, 8, 1, tzinfo=timezone.utc),
    )
    payload = dict(_snapshot_payload(candles))
    payload["symbol"] = "ABCUSDT"
    response = client.post("/inspection/snapshot", json=payload)
    assert response.status_code == 200
    snapshot_id = response.json()["snapshot_id"]

    profile_response = client.get("/profile", params={"snapshot": snapshot_id})
    assert profile_response.status_code == 200
    body = profile_response.json()
    assert body["symbol"] == "ABCUSDT"
    assert body.get("preset") is None
    assert body.get("preset_required") is True


def test_compact_vwap_profiles_incremental_updates() -> None:
    base = datetime(2024, 1, 1, tzinfo=timezone.utc)
    minute_ms = 60_000
    start_ms = int(base.timestamp() * 1000)
    candles = [
        {"t": start_ms, "h": 101.0, "l": 99.0, "c": 100.0, "v": 5.0},
        {"t": start_ms + minute_ms, "h": 102.0, "l": 100.0, "c": 101.0, "v": 6.0},
        {"t": start_ms + 2 * minute_ms, "h": 103.0, "l": 101.0, "c": 102.0, "v": 7.0},
    ]
    daily_window = (start_ms, start_ms + 3 * minute_ms)
    session_windows = {
        "asia": (start_ms, start_ms + 3 * minute_ms, start_ms + 4 * minute_ms),
    }
    token = ("compact_test", "BTCUSDT")

    result_initial = build_compact_vwap_profiles(
        candles,
        daily_window=daily_window,
        composite_window=daily_window,
        session_windows=session_windows,
        tick_size=0.5,
        value_area_pct=0.7,
        cache_token=token,
    )

    assert result_initial.daily is not None
    assert result_initial.daily["bars"] == 3
    assert "asia" in result_initial.sessions
    assert result_initial.session_sigma["asia"]["basis"] == "session"

    extended = candles + [
        {"t": start_ms + 3 * minute_ms, "h": 104.0, "l": 102.0, "c": 103.0, "v": 8.0}
    ]

    result_extended = build_compact_vwap_profiles(
        extended,
        daily_window=daily_window,
        composite_window=daily_window,
        session_windows=session_windows,
        tick_size=0.5,
        value_area_pct=0.7,
        cache_token=token,
    )

    assert result_extended.daily is not None
    assert result_extended.daily["bars"] == 4
    assert result_extended.daily["incremental_bars"] == 1
    assert result_extended.bars_processed >= 1
    asia_session = result_extended.sessions["asia"]
    assert asia_session["bars"] == 4
    assert asia_session["incremental_bars"] == 1
    boundaries = result_extended.session_boundaries["asia"]
    assert boundaries["start_ms"] == session_windows["asia"][0]
