"""Self-training package."""

from .manager import SelfTrainManager

__all__ = ["SelfTrainManager"]
