"""Application metadata."""

APP_VERSION = "0.1.0"
